# Dashboard export integrity report: **PASSED**

- Created (UTC): 2026-10-22T11:03:40Z · exporter 1.0.0 · schema 1
- Checks: 352 PASS · 2 WARN · 4 INFO · 0 FAIL
- Source files fingerprinted before and after: 477 (985.5 MB), unchanged: **True**
- Bundle: 637 files, 26.1 MB (without the manifest and the two integrity-report files)

> All values are copied or computed from the listed source files. Validation set only (12 diagnostic graphs); no test-set results exist. Arm U is a diagnostic deviation (train-time cell-head clamp removed); not a reproduction of the paper.

| Status | Check | Message |
|---|---|---|
| WARN | `report.protected_artifacts` | the report has no protected_artifacts record (notebook 08 writes it as its last report update; an earlier copy of the report lacks it) |
| WARN | `thresholds.recorded_vs_implemented` | documentation inconsistency flagged: recorded p2_min_improvement = 0.1 is not used; implemented: FAIL if improvement <= 0.08; BORDERLINE if 0.08 < improvement < 0.12; PASS if >= 0.12 (diagnostics/headpath.py: p2_outcome). Runs in the disputed interval: none. The report is not modified. |
| INFO | `report.selected` | authoritative report: 08_headpath_experiment.json (sha256 ce485b2569b5d355…) |
| INFO | `sources.fingerprint_before` | 477 source files fingerprinted (sha256 of full content) |
| INFO | `json.normalized.context07/sources/07_collapse_experiment__20261019_191331.json` | context07/sources/07_collapse_experiment__20261019_191331.json: 1 non-finite values -> null (NaN 0, +Infinity 1, -Infinity 0); source untouched (sha256 e80b29e6ae46e06f… before and after) |
| INFO | `json.normalized.headpath/sources/08_headpath_experiment.json` | headpath/sources/08_headpath_experiment.json: 145 non-finite values -> null (NaN 145, +Infinity 0, -Infinity 0); source untouched (sha256 ce485b2569b5d355… before and after) |
| PASS | `plan.matches_report` | every 08_headpath_plan*.json agrees with report.plan (train, val, runs, thresholds, eval steps) |
| PASS | `report.runs` | 14 results for 14 planned runs (expected 14 = 12 primary + 2 retest) |
| PASS | `report.status` | experiment_status = VALID, verdict = VALID |
| PASS | `report.all_completed` | every planned run has run_status COMPLETED |
| PASS | `HEADPATH_O__seed42.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O__seed42.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_O__seed42.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O__seed42.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O__seed42.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O__seed42.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O__seed42.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 0, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U__seed42.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U__seed42.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_U__seed42.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U__seed42.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U__seed42.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U__seed42.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U__seed42.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 0, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_O__seed43.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O__seed43.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_O__seed43.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O__seed43.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O__seed43.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O__seed43.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O__seed43.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 0, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U__seed43.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U__seed43.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_U__seed43.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U__seed43.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U__seed43.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U__seed43.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U__seed43.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 0, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_O__seed44.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O__seed44.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_O__seed44.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O__seed44.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O__seed44.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O__seed44.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O__seed44.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 4.39e-08, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U__seed44.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U__seed44.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_U__seed44.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U__seed44.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U__seed44.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U__seed44.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U__seed44.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 1.77e-06, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_O__seed45.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O__seed45.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_O__seed45.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O__seed45.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O__seed45.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O__seed45.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O__seed45.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 0, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U__seed45.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U__seed45.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_U__seed45.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U__seed45.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U__seed45.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U__seed45.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U__seed45.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 0, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_O__seed46.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O__seed46.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_O__seed46.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O__seed46.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O__seed46.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O__seed46.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O__seed46.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 0, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U__seed46.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U__seed46.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_U__seed46.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U__seed46.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U__seed46.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U__seed46.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U__seed46.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 1.16e-07, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_O__seed47.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O__seed47.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_O__seed47.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O__seed47.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O__seed47.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O__seed47.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O__seed47.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 0, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U__seed47.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U__seed47.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_U__seed47.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U__seed47.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U__seed47.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U__seed47.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U__seed47.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 0, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_O_RETEST__seed42.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O_RETEST__seed42.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_O_RETEST__seed42.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O_RETEST__seed42.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O_RETEST__seed42.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O_RETEST__seed42.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O_RETEST__seed42.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 0, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U_RETEST__seed42.steps` | 490 steps (expected 490), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U_RETEST__seed42.evals` | evaluations at [0, 49, 98, 147, 196, 245, 294, 343, 392, 441, 490] |
| PASS | `HEADPATH_U_RETEST__seed42.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U_RETEST__seed42.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U_RETEST__seed42.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U_RETEST__seed42.predictions_set` | 12 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U_RETEST__seed42.250-mgc_matrix_mult_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.279-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.301-mgc_matrix_mult_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.329-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.362-mgc_matrix_mult_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.383-mgc_matrix_mult_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.215-mgc_des_perf_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.204-mgc_edit_dist_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.166-mgc_fft_a-util_0.75.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.315-mgc_matrix_mult_b-util_0.8.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.3-mgc_pci_bridge32_a-util_0.85.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.50-mgc_pci_bridge32_b-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 490 (max /diff/ 0, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `labels.250-mgc_matrix_mult_a-util_0.85` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.279-mgc_matrix_mult_a-util_0.9` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.301-mgc_matrix_mult_a-util_0.9` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.329-mgc_matrix_mult_a-util_0.75` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.362-mgc_matrix_mult_a-util_0.7` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.383-mgc_matrix_mult_a-util_0.75` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.215-mgc_des_perf_a-util_0.75` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.204-mgc_edit_dist_a-util_0.7` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.166-mgc_fft_a-util_0.75` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.315-mgc_matrix_mult_b-util_0.8` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.3-mgc_pci_bridge32_a-util_0.85` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.50-mgc_pci_bridge32_b-util_0.9` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `maps.shared_once` | label / raw H / raw V / cell-subsample arrays identical across all runs, stored once for 12 samples |
| PASS | `primary_test.rederived` | exact McNemar re-derived from the stored categories (seeds 42-47, retests excluded): 2 discordant, p = 0.5; scipy binomtest p = 0.5 |
| PASS | `primary_test.retests_excluded` | the primary test has one pair per seed 42-47 and no other entry; the HEADPATH_*_RETEST__seed42 runs are not in it (re-derivation above uses non-retest runs only) |
| PASS | `context07.report` | notebook-07 report 07_collapse_experiment__20261019_191331.json: 18 results for 18 planned runs (the executed notebook-07 plan has 18) |
| PASS | `context07.REPLICA__fp16__seed42.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.REPLICA__fp16__seed43.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.REPLICA__fp16__seed44.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.REPLICA__fp32__seed42.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.REPLICA__fp32__seed43.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.REPLICA__fp32__seed44.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.FULL__fp32__seed42.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.FULL__fp32__seed43.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.FULL__fp32__seed44.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.DIVERSE6__fp32__seed42.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.DIVERSE6__fp32__seed43.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.DIVERSE6__fp32__seed44.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.DIVERSE36__fp32__seed42.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.DIVERSE36__fp32__seed43.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.DIVERSE36__fp32__seed44.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.SINGLE6__fp32__seed42.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.SINGLE6__fp32__seed43.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.SINGLE6__fp32__seed44.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `sources.unchanged` | 477 source files re-hashed after the export: added 0, removed 0, modified 0 |
| PASS | `arrays.roundtrip` | 408 arrays decoded again; sha256 of the raw bytes matches (lossless) |
| PASS | `json.normalized.context07/sources/07_collapse_plan.json` | context07/sources/07_collapse_plan.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 4d9fd6eb2ea01a3e… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O_RETEST__seed42/sources/env.json` | headpath/runs/HEADPATH_O_RETEST__seed42/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 1d4e734980399add… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O_RETEST__seed42/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O_RETEST__seed42/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 aa09d3e9525469de… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O_RETEST__seed42/sources/status.json` | headpath/runs/HEADPATH_O_RETEST__seed42/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 cf04e22d16234dcc… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed42/sources/env.json` | headpath/runs/HEADPATH_O__seed42/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 c22d0c283cc9e029… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed42/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O__seed42/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 ef54ad6d1201bc16… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed42/sources/status.json` | headpath/runs/HEADPATH_O__seed42/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 f5e6c6e69c985013… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed43/sources/env.json` | headpath/runs/HEADPATH_O__seed43/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 2ac23c6c66378f00… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed43/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O__seed43/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 921e82e795b6f93c… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed43/sources/status.json` | headpath/runs/HEADPATH_O__seed43/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 4b06200ec16f8b0d… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed44/sources/env.json` | headpath/runs/HEADPATH_O__seed44/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 1206ebaceb64584b… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed44/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O__seed44/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 48fae34c4c883d29… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed44/sources/status.json` | headpath/runs/HEADPATH_O__seed44/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 811e54ae6a50dd26… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed45/sources/env.json` | headpath/runs/HEADPATH_O__seed45/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 1e97a1875c9be568… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed45/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O__seed45/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 bc80377e2b0cbf09… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed45/sources/status.json` | headpath/runs/HEADPATH_O__seed45/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 2bfca5a6e42073a8… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed46/sources/env.json` | headpath/runs/HEADPATH_O__seed46/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 81841870dc3417d6… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed46/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O__seed46/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 97b08b854561bbd3… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed46/sources/status.json` | headpath/runs/HEADPATH_O__seed46/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 7cd7cbf54eb4fecf… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed47/sources/env.json` | headpath/runs/HEADPATH_O__seed47/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 e01fd4d7061f1a8f… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed47/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O__seed47/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 25c92c1fb9bc0adf… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed47/sources/status.json` | headpath/runs/HEADPATH_O__seed47/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 83f58a0082ee27e9… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U_RETEST__seed42/sources/env.json` | headpath/runs/HEADPATH_U_RETEST__seed42/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 803132319014dd1e… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U_RETEST__seed42/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U_RETEST__seed42/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 f3d52f9639c1c3cd… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U_RETEST__seed42/sources/status.json` | headpath/runs/HEADPATH_U_RETEST__seed42/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 266809f5d24b583e… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed42/sources/env.json` | headpath/runs/HEADPATH_U__seed42/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 fed330384632dd4a… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed42/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U__seed42/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 d92d57f65277f3aa… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed42/sources/status.json` | headpath/runs/HEADPATH_U__seed42/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 5db29bbe6fdba462… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed43/sources/env.json` | headpath/runs/HEADPATH_U__seed43/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 316980a86577cb88… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed43/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U__seed43/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 6ddbc54ff3c2deef… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed43/sources/status.json` | headpath/runs/HEADPATH_U__seed43/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 d924f51ca8c4fa10… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed44/sources/env.json` | headpath/runs/HEADPATH_U__seed44/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 0c6163178126588f… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed44/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U__seed44/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 6a8860bcb45b5f6f… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed44/sources/status.json` | headpath/runs/HEADPATH_U__seed44/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 cae3dfe19c317981… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed45/sources/env.json` | headpath/runs/HEADPATH_U__seed45/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 09f9e87cfb26be98… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed45/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U__seed45/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 4ab7dda9514acd52… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed45/sources/status.json` | headpath/runs/HEADPATH_U__seed45/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 eb3047e85f757f5d… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed46/sources/env.json` | headpath/runs/HEADPATH_U__seed46/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 fd1df460445bccff… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed46/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U__seed46/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 e58feb50d68e7643… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed46/sources/status.json` | headpath/runs/HEADPATH_U__seed46/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 eb0aebffc55ff8f1… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed47/sources/env.json` | headpath/runs/HEADPATH_U__seed47/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 a7b6fa0fcbe98c57… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed47/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U__seed47/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 fafae2e43f638577… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed47/sources/status.json` | headpath/runs/HEADPATH_U__seed47/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 7d40cdf6e3e9ec87… before and after) |
| PASS | `json.normalized.headpath/sources/08_headpath_plan.json` | headpath/sources/08_headpath_plan.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 574ceef7c62782f9… before and after) |
| PASS | `json.normalized.headpath/sources/08_headpath_plan__20261020_192429.json` | headpath/sources/08_headpath_plan__20261020_192429.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 574ceef7c62782f9… before and after) |
| PASS | `bundle.strict_json` | every JSON file in the bundle parses as strict JSON (no NaN / Infinity): 134 files checked (manifest and integrity reports are written strictly afterwards and re-checked in the zip) |
