# Dashboard export integrity report: **PASSED**

- Created (UTC): 2026-10-22T11:37:22Z · exporter 1.0.0 · schema 1
- Checks: 237 PASS · 2 WARN · 2 INFO · 0 FAIL
- Source files fingerprinted before and after: 273 (12.5 MB), unchanged: **True**
- Bundle: 352 files, 1.4 MB (without the manifest and the two integrity-report files)

> All values are copied or computed from the listed source files. Validation set only (12 diagnostic graphs); no test-set results exist. Arm U is a diagnostic deviation (train-time cell-head clamp removed); not a reproduction of the paper.

| Status | Check | Message |
|---|---|---|
| WARN | `report.protected_artifacts` | the report has no protected_artifacts record (notebook 08 writes it as its last report update; an earlier copy of the report lacks it) |
| WARN | `thresholds.recorded_vs_implemented` | documentation inconsistency flagged: recorded p2_min_improvement = 0.1 is not used; implemented: FAIL if improvement <= 0.08; BORDERLINE if 0.08 < improvement < 0.12; PASS if >= 0.12 (diagnostics/headpath.py: p2_outcome). Runs in the disputed interval: none. The report is not modified. |
| INFO | `report.selected` | authoritative report: 08_headpath_experiment.json (sha256 5f523761706c4e1c…) |
| INFO | `sources.fingerprint_before` | 273 source files fingerprinted (sha256 of full content) |
| PASS | `plan.matches_report` | every 08_headpath_plan*.json agrees with report.plan (train, val, runs, thresholds, eval steps) |
| PASS | `report.runs` | 14 results for 14 planned runs (expected 14 = 12 primary + 2 retest) |
| PASS | `report.status` | experiment_status = VALID, verdict = VALID - HISTORICAL REPLICATION FAILED (investigate) |
| PASS | `report.all_completed` | every planned run has run_status COMPLETED |
| PASS | `HEADPATH_O__seed42.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O__seed42.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_O__seed42.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O__seed42.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O__seed42.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O__seed42.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O__seed42.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed42.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 1.39e-17, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U__seed42.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U__seed42.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_U__seed42.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U__seed42.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U__seed42.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U__seed42.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U__seed42.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed42.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 1.39e-17, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_O__seed43.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O__seed43.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_O__seed43.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O__seed43.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O__seed43.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O__seed43.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O__seed43.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed43.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 0, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U__seed43.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U__seed43.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_U__seed43.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U__seed43.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U__seed43.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U__seed43.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U__seed43.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed43.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 1.39e-17, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_O__seed44.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O__seed44.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_O__seed44.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O__seed44.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O__seed44.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O__seed44.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O__seed44.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed44.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 2.08e-17, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U__seed44.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U__seed44.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_U__seed44.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U__seed44.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U__seed44.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U__seed44.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U__seed44.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed44.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 2.78e-17, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_O__seed45.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O__seed45.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_O__seed45.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O__seed45.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O__seed45.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O__seed45.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O__seed45.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed45.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 6.94e-18, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U__seed45.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U__seed45.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_U__seed45.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U__seed45.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U__seed45.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U__seed45.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U__seed45.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed45.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 1.39e-17, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_O__seed46.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O__seed46.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_O__seed46.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O__seed46.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O__seed46.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O__seed46.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O__seed46.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed46.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 0, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U__seed46.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U__seed46.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_U__seed46.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U__seed46.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U__seed46.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U__seed46.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U__seed46.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed46.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 1.39e-17, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_O__seed47.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O__seed47.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_O__seed47.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O__seed47.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O__seed47.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O__seed47.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O__seed47.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O__seed47.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 3.47e-17, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U__seed47.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U__seed47.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_U__seed47.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U__seed47.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U__seed47.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U__seed47.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U__seed47.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U__seed47.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 6.94e-18, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_O_RETEST__seed42.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_O_RETEST__seed42.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_O_RETEST__seed42.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_O_RETEST__seed42.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_O_RETEST__seed42.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_O_RETEST__seed42.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_O_RETEST__seed42.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_O_RETEST__seed42.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 1.39e-17, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `HEADPATH_U_RETEST__seed42.steps` | 24 steps (expected 24), losses finite True, gradient norms finite True |
| PASS | `HEADPATH_U_RETEST__seed42.evals` | evaluations at [0, 6, 12, 18, 24] |
| PASS | `HEADPATH_U_RETEST__seed42.rederived` | category, P1/P2/P3, H-sig, grid, per-design, zero reference and optimizer-step count re-derived from the CSVs agree with the report |
| PASS | `HEADPATH_U_RETEST__seed42.checkpoint` | last.pt re-read: equals the report's checkpoint record, epoch, Adam step count = optimizer steps, finite |
| PASS | `HEADPATH_U_RETEST__seed42.predictions_marker` | _COMPLETE.json present and every listed file's sha256 matches |
| PASS | `HEADPATH_U_RETEST__seed42.predictions_set` | 5 prediction files = the 12 validation samples |
| PASS | `HEADPATH_U_RETEST__seed42.10200-mgc_pci_bridge32_a-util_0.7.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.10204-mgc_pci_bridge32_a-util_0.11.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.10302-mgc_des_perf_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.10402-mgc_edit_dist_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.10102-mgc_fft_a-util_0.9.npz` | array keys, shapes, finiteness, clamped (>= 0) official eval outputs, /err/ = /pred - gt/ bit-exact, cell_gt = grid_gt[cell_tile] |
| PASS | `HEADPATH_U_RETEST__seed42.grid_metrics_from_npz` | grid Spearman / zero fraction / std recomputed from the full NPZ maps agree with evals.csv at step 24 (max /diff/ 1.39e-17, tolerance 0.0001: the NPZ comes from a second eval pass; undefined == undefined) |
| PASS | `labels.10200-mgc_pci_bridge32_a-util_0.7` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.10204-mgc_pci_bridge32_a-util_0.11` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.10302-mgc_des_perf_a-util_0.9` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.10402-mgc_edit_dist_a-util_0.9` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `labels.10102-mgc_fft_a-util_0.9` | labels in the predictions equal the processed sample: grid_gt = log1p((H+V)/2)/c_max, raw H and V overflow (kept separate), cell tiles |
| PASS | `maps.shared_once` | label / raw H / raw V / cell-subsample arrays identical across all runs, stored once for 5 samples |
| PASS | `primary_test.rederived` | exact McNemar re-derived from the stored categories (seeds 42-47, retests excluded): 1 discordant, p = 1; scipy binomtest p = 1.0 |
| PASS | `primary_test.retests_excluded` | the primary test has one pair per seed 42-47 and no other entry; the HEADPATH_*_RETEST__seed42 runs are not in it (re-derivation above uses non-retest runs only) |
| PASS | `context07.report` | notebook-07 report 07_collapse_experiment__synthetic.json: 6 results for 6 planned runs (the executed notebook-07 plan has 18) |
| PASS | `context07.REPLICA__fp16__seed42.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.REPLICA__fp32__seed42.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.FULL__fp32__seed42.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.DIVERSE6__fp32__seed42.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.DIVERSE36__fp32__seed42.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `context07.SINGLE6__fp32__seed42.collapse` | collapsed / collapse step / zero-gradient steps re-derived from steps.csv agree with the notebook-07 report |
| PASS | `sources.unchanged` | 273 source files re-hashed after the export: added 0, removed 0, modified 0 |
| PASS | `arrays.roundtrip` | 170 arrays decoded again; sha256 of the raw bytes matches (lossless) |
| PASS | `json.normalized.context07/sources/07_collapse_experiment__synthetic.json` | context07/sources/07_collapse_experiment__synthetic.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 46471e86c50f8fbb… before and after) |
| PASS | `json.normalized.context07/sources/07_collapse_plan.json` | context07/sources/07_collapse_plan.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 b934e541c2e81f37… before and after) |
| PASS | `json.normalized.context07/sources/07_forensic_audit.json` | context07/sources/07_forensic_audit.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 f441cb6f6855587e… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O_RETEST__seed42/sources/env.json` | headpath/runs/HEADPATH_O_RETEST__seed42/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 4f391a17a9d21f05… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O_RETEST__seed42/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O_RETEST__seed42/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 b44bbb61a64e9d95… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O_RETEST__seed42/sources/status.json` | headpath/runs/HEADPATH_O_RETEST__seed42/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 f238d922f6392804… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed42/sources/env.json` | headpath/runs/HEADPATH_O__seed42/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 380d6883fdc3dbb1… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed42/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O__seed42/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 be30af468562a47f… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed42/sources/status.json` | headpath/runs/HEADPATH_O__seed42/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 ec5fe05ade608cc5… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed43/sources/env.json` | headpath/runs/HEADPATH_O__seed43/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 32874240a227f7c8… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed43/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O__seed43/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 c2d37554b02ae916… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed43/sources/status.json` | headpath/runs/HEADPATH_O__seed43/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 6e46d01164da6b52… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed44/sources/env.json` | headpath/runs/HEADPATH_O__seed44/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 619048a1ba8a7fdf… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed44/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O__seed44/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 6545668dd8c2653b… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed44/sources/status.json` | headpath/runs/HEADPATH_O__seed44/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 fec4648a55853f78… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed45/sources/env.json` | headpath/runs/HEADPATH_O__seed45/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 8d17fde0cbc37097… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed45/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O__seed45/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 f5be36c4b98401c3… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed45/sources/status.json` | headpath/runs/HEADPATH_O__seed45/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 bc32906e24e306cb… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed46/sources/env.json` | headpath/runs/HEADPATH_O__seed46/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 a1370185f9d8091e… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed46/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O__seed46/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 f078a18441b5f840… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed46/sources/status.json` | headpath/runs/HEADPATH_O__seed46/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 e411eea20359ad89… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed47/sources/env.json` | headpath/runs/HEADPATH_O__seed47/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 4cf5c74ab629b335… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed47/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_O__seed47/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 a1d498a4f4454cf5… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_O__seed47/sources/status.json` | headpath/runs/HEADPATH_O__seed47/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 c63a8258a3b5e8f6… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U_RETEST__seed42/sources/env.json` | headpath/runs/HEADPATH_U_RETEST__seed42/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 0b5e3b8938aadd40… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U_RETEST__seed42/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U_RETEST__seed42/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 50166e30a8a019be… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U_RETEST__seed42/sources/status.json` | headpath/runs/HEADPATH_U_RETEST__seed42/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 8ed4ef8ea7a1f1c3… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed42/sources/env.json` | headpath/runs/HEADPATH_U__seed42/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 7e0d83920a112845… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed42/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U__seed42/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 a37908d8c575a6f1… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed42/sources/status.json` | headpath/runs/HEADPATH_U__seed42/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 9687d52327d9fb25… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed43/sources/env.json` | headpath/runs/HEADPATH_U__seed43/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 2bc0e64533f31434… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed43/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U__seed43/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 8cc01132e5fccc22… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed43/sources/status.json` | headpath/runs/HEADPATH_U__seed43/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 e41e0be2f58966e8… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed44/sources/env.json` | headpath/runs/HEADPATH_U__seed44/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 ac3800e0c72c6dad… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed44/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U__seed44/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 f1fe9f806c5cbbfd… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed44/sources/status.json` | headpath/runs/HEADPATH_U__seed44/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 c884b16da8fdc9b1… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed45/sources/env.json` | headpath/runs/HEADPATH_U__seed45/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 8c8d7351e3b56202… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed45/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U__seed45/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 f05e099466c2b1bb… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed45/sources/status.json` | headpath/runs/HEADPATH_U__seed45/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 0971850f835d9471… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed46/sources/env.json` | headpath/runs/HEADPATH_U__seed46/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 0ea0631d2176e742… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed46/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U__seed46/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 08d8dbf24bd0faf3… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed46/sources/status.json` | headpath/runs/HEADPATH_U__seed46/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 6b2c5ea32ebde4bc… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed47/sources/env.json` | headpath/runs/HEADPATH_U__seed47/sources/env.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 b4e78ec483d02028… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed47/sources/predictions_COMPLETE.json` | headpath/runs/HEADPATH_U__seed47/sources/predictions_COMPLETE.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 f6dcf1c0c4d0e520… before and after) |
| PASS | `json.normalized.headpath/runs/HEADPATH_U__seed47/sources/status.json` | headpath/runs/HEADPATH_U__seed47/sources/status.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 e32f79165b7f6a2f… before and after) |
| PASS | `json.normalized.headpath/sources/08_headpath_experiment.json` | headpath/sources/08_headpath_experiment.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 5f523761706c4e1c… before and after) |
| PASS | `json.normalized.headpath/sources/08_headpath_plan.json` | headpath/sources/08_headpath_plan.json: 0 non-finite values -> null (NaN 0, +Infinity 0, -Infinity 0); source untouched (sha256 4489ad4fb0d553a3… before and after) |
| PASS | `bundle.strict_json` | every JSON file in the bundle parses as strict JSON (no NaN / Infinity): 111 files checked (manifest and integrity reports are written strictly afterwards and re-checked in the zip) |
